# Package charging
library(tidyverse) 
library(gridExtra) 

library(ipumsr)
library(dplyr)
library(purrr)

install.packages("tmap")
library(tmap)
library(sf)
library(ggplot2)

library(viridis)
library(leaflet)
install.packages("rmapshaper")
library(rmapshaper)

# Let's define our working directory
getwd()
setwd("C:/Users/haria/OneDrive/Documents/data visualisation")

ipums_data_collections()
# Save key in .Renviron for use across sessions
set_ipums_api_key("59cba10d8a5da536fc06b59d8c3a17f0c32f48618a1b0fc868d1b494", save = TRUE)

#*Let's load the shapefile for US counties and select only states in the contiguous US,
#*it means we remove Alaska and Hawai.

nhgis_ext <- define_extract_nhgis(
  description = "County shapefiles (2020)",
  shapefiles = "us_county_2020_tl2020"
)
nhgis_ext_submitted <- submit_extract(nhgis_ext)
nhgis_ext_complete <- wait_for_extract(nhgis_ext_submitted)
filepath <- download_extract(nhgis_ext_submitted,
                             download_dir = "data/raw")

shape_us <- read_ipums_sf(paste0("data/raw/nhgis0038_shape.zip"))

# contiguous states / counties 
shape_us %>% 
  mutate(STATEFP = as.integer(STATEFP)) %>%
  filter(STATEFP < 57) %>% 
  filter(!(STATEFP %in% c(2,15))) ->
  shape_us

shape_us

# Time series tables do not contain individual data tables, 
#   but do require a geographic level selection, and allow an optional selection of years

nhgis_ext <- define_extract_nhgis(
  description = "CW8: Persons by Sex by Race at county level",
  time_series_tables = tst_spec(
    "CW8",
    geog_levels = c("county"),
    years = c("2010")
  )
)
nhgis_ext_submitted <- submit_extract(nhgis_ext)
nhgis_ext_complete <- wait_for_extract(nhgis_ext_submitted)
filepath <- download_extract(nhgis_ext_submitted,
                             download_dir = "data/raw")
nhgis_data <- read_nhgis(filepath)

nhgis_data <- read_nhgis("data/raw/nhgis0039_csv.zip")

nhgis_data <- nhgis_data |>
  mutate(pop_white  = CW8AA2010 + CW8AG2010,
         pop_black  = CW8AB2010 + CW8AH2010,
         pop_native = CW8AC2010 + CW8AI2010, 
         pop_asian  = CW8AD2010 + CW8AJ2010, 
         pop_other  = CW8AE2010 + CW8AK2010,
         pop_two_or_more = CW8AF2010 + CW8AL2010,
         total_pop  = pop_white + pop_black + pop_native + pop_asian + pop_other + pop_two_or_more)

nhgis_data <- nhgis_data |>
  select(GISJOIN, GEOGYEAR, STATE, STATEA, COUNTY, COUNTYA,
         pop_white, pop_black, pop_native, pop_asian, pop_other, 
         pop_two_or_more, total_pop)

shape_us <- shape_us %>%
  left_join(nhgis_data, by = "GISJOIN") %>%
  filter(!STATEFP %in% c("02", "15", "72"))

shape_us %>%
  filter(GEOGYEAR == 2010) ->
  shape_us

shape_us

summary(shape_us)

shape_us <- shape_us |>
  select(-STATEA, -COUNTYA, -NAME, -COUNTY, -MTFCC, -METDIVFP, -FUNCSTAT, -CLASSFP) |>
  rename(COUNTY = NAMELSAD)

#* TASK 1
#* Los Angeles County has fip code : 06037

los_angeles <- shape_us |>
  filter(GEOID == "06037")

# Total population of Los Angeles is 9818605 habitants like it says in 2010 United States Census 
# according to Wikipedia

#*The racial makeup, according to wikipedia, of Los Angeles County was 4,936,599 (50.3%) White, 
#*856,874 (8.7%) African American, 72,828 (0.7%) Native American, 1,346,865 (13.7%) Asian, 
#*26,094 (0.3%) Pacific Islander, 2,140,632 (21.8%) from other races, 
#*and 438,713 (4.5%) from two or more races.

#*In our database, their put Pacifique Islander in Asian category, so we have 
#*1,346,865 + 26,094 = 1 372 959 Asians.

# Mettre les données en format long
los_angeles_long <- los_angeles |>
  st_drop_geometry() |>
  select(pop_white, pop_black, pop_native, pop_asian, pop_other, pop_two_or_more) |>
  rename(White = pop_white,
         Black = pop_black,
         Asian = pop_asian,
         Native = pop_native,
         Other = pop_other,
         Two_or_more = pop_two_or_more) |>
  pivot_longer(everything(),
               names_to = "race",
               values_to = "population")

los_angeles_long <- los_angeles_long |>
  mutate(share = population / sum(population),
    race_clean = case_when(
      race == "White" ~ "White",
      race == "Black" ~ "Black",
      race == "Asian" ~ "Asian",
      race == "Native" ~ "Native",
      race == "Other" ~ "Other",
      race == "Two_or_more" ~ "Two or More"),
    label = paste0(race_clean, " (", scales::percent(share, accuracy = 0.1), ")"))

ggplot(los_angeles_long, aes(x = population, y = reorder(race_clean, share), fill = race_clean)) +
  geom_col(width = 0.7, color = "black") +
  
  geom_text(
    aes(label = label, hjust = ifelse(share < 0.09, -0.1, 1.05)),
    color = ifelse(los_angeles_long$share < 0.09, "black", "white"),
    size = 4.2, fontface = "bold") +
  
  scale_fill_manual(values = c(
    "White" = "#d65ad1",
    "Other" = "#19a7a8",
    "Asian" = "#f06c64",
    "Black" = "#b59a00",
    "Two or More" = "#5b8bd9",
    "Native" = "#00b050"
  )) +
  
  scale_x_continuous(labels = scales::comma, expand = expansion(mult = c(0, 0.15)))+
  
  labs(title = "Los Angeles County – Population Share by Race (2010)",
    x = "Population",
    y = "Race") +
  
  theme_minimal(base_size = 14) +
  theme(
    panel.border = element_rect(color = "black", fill = NA, linewidth = 1),
    legend.position = "none",
    plot.title = element_text(face = "bold"),
    axis.text.y = element_blank(),
    axis.ticks.y = element_blank(),
    plot.margin = margin(10, 20, 10, 40)) +
  
  coord_flip() +
  coord_cartesian(clip = "off")

# TASK 2

shape_us <- shape_us |>
  mutate(
    pop_class = cut(
      total_pop,
      breaks = c(82, 7036, 13009, 20680, 32542, 54701, 131842, 9818605),
      labels = c(
        "82 - 7,036",
        "7,036 – 13,009",
        "13,009 – 20,680",
        "20,680 – 32,542",
        "32,542 – 54,701",
        "54,701 – 131,842",
        "131,842 – 9,818,605"
      ),
      include.lowest = TRUE,
      right = TRUE
    )
  )

# Projection 
shape_us_proj <- st_transform(shape_us, 2163)

m_pop <- tm_shape(shape_us_proj) +
  tm_polygons(
    col = "pop_class",
    palette = "YlOrRd",
    border.col = "gray50",
    border.alpha = 0.5,
    title = "",
    showNA = TRUE
  ) +
  tm_layout(
    title = "Population totale par comté",
    title.position = c("center", "top"),
    plot.title = element_text(face = "bold", size = 16, hjust = 0.5),
    legend.position = c("left", "bottom"),
    legend.justification = c(1, 0),
    frame = FALSE,
    inner.margins = c(0.1, 0.1, 0.05, 0.05)
  )

m_pop

# TASK 3 : Transformons la carte en une application leaflet.
# Ajoutons un popup
# Fournissons une capture d’écran du rendu HTML de la carte leaflet comme preuve que le code fonctionne, 
# et fournissons aussi le code.

gc()
sf_use_s2(FALSE)

# ÉTAPE 1 : simplifier d'abord en projection originale (mètres)
shape_us_light <- st_simplify(shape_us, dTolerance = 500, preserveTopology = TRUE)

# ÉTAPE 2 : ensuite transformer en WGS84
shape_us_light <- st_transform(shape_us_light, crs = 4326)
shape_us_light <- st_make_valid(shape_us_light)

gc()

# ÉTAPE 3 : palette
pal_fun <- colorBin(
  palette = "YlOrBr",
  domain = shape_us_light$total_pop,
  bins = c(82, 7036, 13009, 20680, 32542, 54701, 131842, 9818605),
  na.color = "grey80"
)

# ÉTAPE 4 : carte
ma_carte <- leaflet(shape_us_light) %>%
  addProviderTiles(providers$CartoDB.Positron) %>%
  addPolygons(
    stroke = TRUE, color = "black", opacity = .2, weight = 0.5,
    fillColor = ~pal_fun(total_pop),
    fillOpacity = 0.8, smoothFactor = 0.5,
    popup = ~paste0(
      "<b>", COUNTY, "</b><br>",
      "Population : ", format(total_pop, big.mark = ",", scientific = FALSE)
    ),
    group = "county"
  ) %>%
  addLegend(
    pal = pal_fun,
    values = ~total_pop,
    title = "Population totale",
    position = "bottomleft",
    labFormat = labelFormat(big.mark = ","),
    na.label = "Missing"
  )

ma_carte


# TASK 4 Nous allons, ici, générer un dashboard interactif où l'utilisateur pourra manuellement sélectionner
# la comté

# ÉTAPE 1 : librairies
library(shiny)
library(tigris)
library(dplyr)
library(tidyr)
library(stringr)

# ÉTAPE 1 : préparer les données
counties_WGS84 <- sf::st_transform(shape_us, 4326)

us_states <- sf::st_transform(us_states, 4326) %>%
  mutate(STATEFP = as.integer(STATEFP)) %>%
  filter(STATEFP < 57) %>%
  filter(!(STATEFP %in% c(2, 15)))

us_state_centroids <- sf::st_centroid(us_states)

# ÉTAPE 2 : palette
bks <- mapsf::mf_get_breaks(counties_WGS84$total_pop, nbreaks = 7, breaks = "quantile")
pal_fun <- colorQuantile("YlOrBr", NULL, n = 7)

# ÉTAPE 3 : UI
ui <- fluidPage(
  titlePanel("US county population in 2010"),
  sidebarLayout(
    sidebarPanel(
      uiOutput("select_state"),
      uiOutput("counties_in_state")
    ),
    mainPanel(
      leafletOutput("map"),
      textOutput("text"),
      plotOutput("BarPlot")
    )
  )
)

# ÉTAPE 4 : Server
server <- function(input, output, session) {
  
  output$select_state <- renderUI({
    selectInput(
      "select_state",
      "State:",
      choices = sort(unique(counties_WGS84$STATE)),
      selected = "Alabama"
    )
  })
  
  output$counties_in_state <- renderUI({
    req(input$select_state)
    selectInput(
      "select_county",
      "County:",
      choices = counties_WGS84$COUNTY[counties_WGS84$STATE == input$select_state]
    )
  })
  
  output$BarPlot <- renderPlot({
    req(input$select_county)
    
    counties_WGS84 %>%
      st_drop_geometry() %>%
      select(GEOID, GEOGYEAR, COUNTY, 
             pop_white, pop_black, pop_native, pop_asian, pop_other) %>%  # Sélection des bonnes colonnes
      filter(COUNTY == input$select_county, GEOGYEAR == 2010) %>%
      pivot_longer(cols = starts_with("pop"), names_to = "race", values_to = "population") %>%
      mutate(race = str_sub(race, start = 5)) %>%
      mutate(race = factor(race, levels = c("white", "black", "asian", "native", "other"))) %>%
      mutate(pop_share = population / sum(population)) ->
      temp
    
    # Graphique p1 - Population par race
    p1 <- ggplot(temp, aes(y = race, x = population, fill = race)) +
      geom_col() +
      geom_text(aes(label = race, x = max(population) * .1), size = 5, nudge_x = 0.3) +
      labs(title = paste0("County: ", temp$COUNTY[1])) +
      theme_bw() +
      theme(legend.position = "none", axis.text.y = element_blank())
    
    # Graphique p2 - Part de la population avec ajout de pourcentages
    p2 <- ggplot(temp, aes(y = race, x = pop_share, fill = race)) +
      geom_col() +
      geom_text(aes(label = scales::percent(pop_share), x = pop_share + 0.03), size = 5) +  # Ajout des pourcentages
      labs(x = "Population Share", y = "", title = "") +
      theme_bw() +
      theme(legend.position = "none", axis.text.y = element_blank())
    
    gridExtra::grid.arrange(p1, p2, nrow = 1)
  })
  
  output$map <- renderLeaflet({
    p_popup <- paste0("<strong>Total Population: </strong>", counties_WGS84$total_pop, "<br>",
                      "<strong>County ID: </strong>", counties_WGS84$GEOID, "<br>",
                      "<strong>County: </strong>", counties_WGS84$COUNTY, "<br>",
                      "<strong>State: </strong>", counties_WGS84$STATE)
    
    leaflet() %>%
      addPolygons(data = us_states$geometry,
                  stroke = TRUE, color = "black", opacity = .2, weight = 2,
                  group = "state") %>%
      addLabelOnlyMarkers(data = us_state_centroids$geometry,
                          label = us_state_centroids$NAME,
                          labelOptions = labelOptions(
                            noHide = TRUE,
                            direction = 'top',
                            textOnly = TRUE
                          ),
                          group = "state") %>%
      addPolygons(data = counties_WGS84,
                  stroke = FALSE,
                  fillColor = ~pal_fun(total_pop),
                  fillOpacity = 0.8, smoothFactor = 0.5,
                  popup = p_popup,
                  group = "county",
                  layerId = counties_WGS84$GEOID) %>%
      addLegend("bottomright",
                colors = RColorBrewer::brewer.pal(7, "YlOrBr"),
                labels = paste0("up to ", format(bks[-1], digits = 2)),
                title = 'Total Pop.') %>%
      addLayersControl(overlayGroups = c("state"), baseGroups = c("county"))
  })
  
  observeEvent(input$map_shape_click, {
    output$text <- renderText({
      paste0("county id: ", input$map_shape_click$id)
    })
    
    clicked_state <- counties_WGS84$STATE[counties_WGS84$GEOID == input$map_shape_click$id]
    clicked_county <- counties_WGS84$COUNTY[counties_WGS84$GEOID == input$map_shape_click$id]
    
    updateSelectInput(session, inputId = "select_state",
                      selected = clicked_state)
    
    updateSelectInput(session, inputId = "select_county",
                      choices = counties_WGS84$COUNTY[counties_WGS84$STATE == clicked_state],
                      selected = clicked_county)
  })
}

shinyApp(ui, server)

names(counties_WGS84)